function main() {
    console.log("Hello, LaTeX!");
}